// Require module:
var MY_SLACK_WEBHOOK_URL = 'https://hooks.slack.com/services/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';
var slack = require('slack-notify')(MY_SLACK_WEBHOOK_URL);


slack.alert({
  text: ':sparkles: New version alive',
  fields: {
    'Information': 'Data base updated',
    'link': 'http://wolf-whale.flinked.fr/'
  },
});